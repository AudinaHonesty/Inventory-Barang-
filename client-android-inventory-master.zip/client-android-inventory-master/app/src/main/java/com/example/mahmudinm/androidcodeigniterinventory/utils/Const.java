package com.example.mahmudinm.androidcodeigniterinventory.utils;

public class Const {

    public static final String URL = "http://192.168.100.9/android_codeigniter_inventory/";

}
